/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

public class Main
{ 
    // RETURN SMALLEST ELEMENT OF THE ARRAY
    
	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	    int arr[] = new int[5];
	    System.out.println("enter element for array");
		for( int i=0; i<5; i++){
		    arr[i] = scn.nextInt();
		}
		Arrays.sort(arr);
		System.out.println(arr[0]);
		
	}
}

